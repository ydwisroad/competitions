class SimpleLossCompute:
    "A simple loss compute and train function."

    def __init__(self, generator, criterion, opt=None):
        self.generator = generator
        # criterion 为LabelSmoothing方法
        self.criterion = criterion
        self.opt = opt

    def __call__(self, x, y, norm):
        # x对对应于out，也就是预测的时刻[batch_size,max_length-1,vocab_size]
        # y对应于trg_y,也就是t时刻 [batch_size,max_length-1]
        x = self.generator(x)

        # x.contiguous().view(-1, x.size(-1)) ====>[batch_size*max_length-1,vocab_size]
        # y.contiguous().view(-1)=========>[batch_size*max_length-1]
        loss = self.criterion(x.contiguous().view(-1, x.size(-1)),
                              y.contiguous().view(-1)) / norm
        loss.backward()
        if self.opt is not None:
            self.opt.step()
            self.opt.optimizer.zero_grad()
        return loss.data.item() * norm