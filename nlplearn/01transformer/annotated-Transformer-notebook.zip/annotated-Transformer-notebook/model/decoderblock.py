
import torch.nn as nn
from .subutils import clones,LayerNorm,SublayerConnection

# 传入参数
# Decoder(DecoderLayer(d_model, c(attn), c(attn), c(ff), dropout), N)
class Decoder(nn.Module):
    "Generic N layer decoder with masking."

    def __init__(self, layer, N):
        super(Decoder, self).__init__()
        self.layers = clones(layer, N)
        self.norm = LayerNorm(layer.size)

    def forward(self, x, memory, src_mask, tgt_mask):
        for layer in self.layers:
            x = layer(x, memory, src_mask, tgt_mask)
        return self.norm(x)


# 传入参数
# DecoderLayer(d_model, c(attn), c(attn), c(ff), dropout), N
class DecoderLayer(nn.Module):
    "Decoder is made of self-attn, src-attn, and feed forward (defined below)"

    def __init__(self, size, self_attn, src_attn, feed_forward, dropout):
        super(DecoderLayer, self).__init__()
        self.size = size
        self.self_attn = self_attn
        self.src_attn = src_attn
        self.feed_forward = feed_forward
        self.sublayer = clones(SublayerConnection(size, dropout), 3)

    # memory就是encoder完成之后的结果
    def forward(self, x, memory, src_mask, tgt_mask):
        "Follow Figure 1 (right) for connections."
        m = memory

        # self-attetion q=k=v,输入是decoder的embedding+positonal
        x = self.sublayer[0](x, lambda x: self.self_attn(x, x, x, tgt_mask))

        # soft-attention q!=k=v x是deocder的embedding，m是encoder的输出
        x = self.sublayer[1](x, lambda x: self.src_attn(x, m, m, src_mask))
        return self.sublayer[2](x, self.feed_forward)